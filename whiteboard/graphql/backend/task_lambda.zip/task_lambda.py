import json
import os
import uuid
import boto3
from typing import Protocol
from abc import abstractmethod
from dataclasses import dataclass, field, asdict
from enum import StrEnum
from typing import Optional
from datetime import datetime

# load environment variable
AWS_REGION = os.environ.get('AWS_REGION', "ap-southeast-2")
TASKS_TABLE = os.environ.get("TASKS_TABLE", "Tasks")
DYNAMODB_ENDPOINT = os.environ.get("DYNAMODB_ENDPOINT", )
# init dynamodb in coldstart, reduced retry
dynamodb = boto3.resource(
    "dynamodb",
    region_name=AWS_REGION,
    endpoint_url=os.getenv("DYNAMODB_ENDPOINT", "http://host.docker.internal:4566")
    # Ensure compatibility inside Docker
)

table = dynamodb.Table(TASKS_TABLE)

# CONSTANTS_LITERALS
ERROR_TASK_ID_MISSING = "No Task ID provided"
ERROR_TASK_NOT_FOUND = "Task not found"


class TaskStatus(StrEnum):
    IN_PROGRESS = "IN_PROGRESS"
    TO_DO = "TO_DO"
    COMPLETED = "COMPLETED"


@dataclass
class Task:
    title: str
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    status: TaskStatus = field(default=TaskStatus.TO_DO)
    description: Optional[datetime] = field(default=None)
    due_date: Optional[str] = field(default="NA")


class EventProcessor(Protocol):
    """
    processor to handle events
    """

    @abstractmethod
    def process(self, event: dict) -> dict:
        """
        process event based on type { Mutation, Query }
        """


class TaskCreateProcessor(EventProcessor):
    # handle task creation event
    def process(self, args: dict) -> dict:
        try:
            task = Task(
                title=args["title"],
                description=args.get("description", ""),
                status=args.get("status", TaskStatus.TO_DO),
                due_date=args.get("due_date", None)
            )
            valid_task = asdict(task)
            table.put_item(Item=asdict(valid_task))
            return valid_task
        # catching generic exception, better to catch specific
        except Exception as ex:
            print("exception in TaskCreateProcessor", str(ex))
            return {"error": str(ex)}


class TaskRetrieveProcessor(EventProcessor):
    def process(self, args: dict) -> dict:
        try:
            task_id = args.get("task_id", None)
            if task_id is None:
                return {"error": ERROR_TASK_ID_MISSING}
            task = table.get_item(Key={"id": task_id})
            if task is None:
                return {"error": f"{ERROR_TASK_NOT_FOUND} for {task_id}"}
            return task
        except Exception as ex:
            print("exception in TaskCreateProcessor", str(ex))
            return {"error": str(ex)}


class UnknownTaskProcessor(EventProcessor):
    def process(self, args: dict) -> dict:
        return {"error": "Unknown task event"}


def processor_factory(event_type):
    match event_type:
        case "createTask":
            return TaskCreateProcessor()
        case "updateTask":
            return UnknownTaskProcessor()  # TaskUpdateProcessor()
        case "deleteTask":
            return UnknownTaskProcessor()  # TaskDeleteProcessor()
        case "getTask":
            return TaskRetrieveProcessor()
        case _:
            return UnknownTaskProcessor()  # UnknownTaskProcessor()


def handler(event, context):
    print("event details:", json.dumps(event))
    try:
        field = event.get("field")
        processor = processor_factory(field)
        args = event.get("arguments")
        print(f"fields {field} and arguments {args}")
        return processor.process(args)

    # TODO should filterout generic exception
    except Exception as ex:
        print("exception in handler ", str(ex))
        return {"error": str(ex)}
